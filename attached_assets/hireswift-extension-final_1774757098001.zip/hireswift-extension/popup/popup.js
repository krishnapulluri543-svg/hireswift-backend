import { API, CONFIG } from '../config.js';

let token = null;
let user = null;

async function init() {
  const result = await chrome.storage.local.get([CONFIG.TOKEN_KEY, CONFIG.USER_KEY]);
  if (!result[CONFIG.TOKEN_KEY]) {
    window.location.href = '../auth/login.html';
    return;
  }
  token = result[CONFIG.TOKEN_KEY];
  user = result[CONFIG.USER_KEY];

  document.getElementById('agentInfo').textContent = `Signed in as ${user.name || user.email}`;
  document.getElementById('logoutBtn').addEventListener('click', logout);

  await loadStudents();
}

async function loadStudents() {
  const loading = document.getElementById('loadingState');
  const errorState = document.getElementById('errorState');
  const list = document.getElementById('studentList');
  const empty = document.getElementById('emptyState');

  try {
    const res = await fetch(API.ASSIGNED_STUDENTS, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (res.status === 401) { logout(); return; }
    const data = await res.json();
    loading.style.display = 'none';

    const students = data.students || [];
    if (!students.length) { empty.style.display = 'block'; return; }

    students.forEach(s => {
      const card = document.createElement('div');
      card.className = 'student-card';
      const priority = (s.priority || 'normal').toLowerCase();
      card.innerHTML = `
        <div>
          <div class="student-name">${s.name || s.fullName || 'Student'}</div>
          <div class="student-email">${s.email}</div>
        </div>
        <div class="student-meta">
          <span class="badge badge-${priority}">${s.priority || 'Normal'}</span>
          <span class="job-count">${s.pendingJobs || 0} jobs</span>
        </div>`;
      card.addEventListener('click', () => openStudent(s));
      list.appendChild(card);
    });
  } catch (err) {
    loading.style.display = 'none';
    errorState.textContent = 'Failed to load students. Check your connection.';
    errorState.style.display = 'block';
  }
}

async function openStudent(student) {
  await chrome.storage.local.set({ [CONFIG.CURRENT_STUDENT_KEY]: student });
  // Open side panel
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.sidePanel.open({ tabId: tab.id });
  window.close();
}

async function logout() {
  await chrome.storage.local.clear();
  window.location.href = '../auth/login.html';
}

init();
