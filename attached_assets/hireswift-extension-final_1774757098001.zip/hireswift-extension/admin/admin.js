import { API, CONFIG } from '../config.js';

let token = null;

async function init() {
  const result = await chrome.storage.local.get([CONFIG.TOKEN_KEY, CONFIG.USER_KEY]);
  if (!result[CONFIG.TOKEN_KEY]) { window.location.href = '../auth/login.html'; return; }
  token = result[CONFIG.TOKEN_KEY];

  document.getElementById('logoutBtn').addEventListener('click', async () => {
    await chrome.storage.local.clear();
    window.location.href = '../auth/login.html';
  });

  setupTabs();
  loadStats();

  document.getElementById('createBtn').addEventListener('click', createUser);
}

function setupTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
      tab.classList.add('active');
      const target = document.getElementById(`tab-${tab.dataset.tab}`);
      target.style.display = 'block';
      if (tab.dataset.tab === 'users') loadUsers();
    });
  });
}

async function loadStats() {
  const grid = document.getElementById('statsGrid');
  try {
    const res = await fetch(API.ADMIN_STATS, { headers: { Authorization: `Bearer ${token}` } });
    const data = await res.json();
    const stats = data.stats || {};
    grid.innerHTML = `
      <div class="stat-card"><div class="stat-num">${stats.totalStudents || 0}</div><div class="stat-label">Students</div></div>
      <div class="stat-card"><div class="stat-num">${stats.totalAgents || 0}</div><div class="stat-label">Agents</div></div>
      <div class="stat-card"><div class="stat-num">${stats.totalJobs || 0}</div><div class="stat-label">Total Jobs</div></div>
      <div class="stat-card"><div class="stat-num">${stats.appliedJobs || 0}</div><div class="stat-label">Applied</div></div>`;
  } catch {
    grid.innerHTML = '<p style="color:#555;font-size:12px">Failed to load stats.</p>';
  }
}

async function loadUsers() {
  const list = document.getElementById('usersList');
  list.innerHTML = '<p style="color:#555;font-size:12px;padding:10px">Loading...</p>';
  try {
    const res = await fetch(API.ADMIN_USERS, { headers: { Authorization: `Bearer ${token}` } });
    const data = await res.json();
    const users = data.users || [];
    list.innerHTML = users.map(u => `
      <div class="user-item">
        <div class="user-name">${u.name || u.fullName || 'User'} <span class="role-badge role-${u.role}">${u.role}</span></div>
        <div class="user-meta">${u.email}</div>
      </div>`).join('') || '<p style="color:#555;font-size:12px">No users found.</p>';
  } catch {
    list.innerHTML = '<p style="color:#f87171;font-size:12px">Failed to load users.</p>';
  }
}

async function createUser() {
  const name = document.getElementById('newName').value.trim();
  const email = document.getElementById('newEmail').value.trim();
  const password = document.getElementById('newPassword').value;
  const role = document.getElementById('newRole').value;
  const errEl = document.getElementById('createError');
  const successEl = document.getElementById('createSuccess');
  const btn = document.getElementById('createBtn');

  errEl.style.display = 'none';
  successEl.style.display = 'none';

  if (!name || !email || !password) {
    errEl.textContent = 'All fields are required.';
    errEl.style.display = 'block';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Creating...';

  try {
    const res = await fetch(API.ADMIN_USERS, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, role })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to create user');
    successEl.textContent = `✓ User ${email} created successfully!`;
    successEl.style.display = 'block';
    document.getElementById('newName').value = '';
    document.getElementById('newEmail').value = '';
    document.getElementById('newPassword').value = '';
  } catch (err) {
    errEl.textContent = err.message;
    errEl.style.display = 'block';
  } finally {
    btn.disabled = false;
    btn.textContent = 'Create User';
  }
}

init();
