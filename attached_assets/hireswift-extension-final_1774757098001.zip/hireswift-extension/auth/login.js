import { API, CONFIG } from '../config.js';

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const btnText = document.getElementById('btnText');
  const btnLoader = document.getElementById('btnLoader');
  const errorMsg = document.getElementById('errorMsg');

  btnText.style.display = 'none';
  btnLoader.style.display = 'inline';
  errorMsg.style.display = 'none';
  document.getElementById('loginBtn').disabled = true;

  try {
    const res = await fetch(API.LOGIN, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.message || 'Login failed');

    await chrome.storage.local.set({
      [CONFIG.TOKEN_KEY]: data.token,
      [CONFIG.USER_KEY]: { ...data.user, expiresAt: Date.now() + 24 * 60 * 60 * 1000 }
    });

    // Redirect based on role
    const role = data.user.role;
    if (role === 'admin') {
      window.location.href = '../admin/admin.html';
    } else if (role === 'agent') {
      window.location.href = '../popup/popup.html';
    } else {
      window.location.href = '../student/student.html';
    }

  } catch (err) {
    errorMsg.textContent = err.message;
    errorMsg.style.display = 'block';
  } finally {
    btnText.style.display = 'inline';
    btnLoader.style.display = 'none';
    document.getElementById('loginBtn').disabled = false;
  }
});

document.getElementById('googleBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: API.GOOGLE });
});
