// HireSwift Configuration
export const CONFIG = {
  TOKEN_KEY: 'hireswiftToken',
  USER_KEY: 'hireswiftUser',
  CURRENT_STUDENT_KEY: 'currentStudent',
  CURRENT_JOB_KEY: 'currentJob'
};

const BASE_URL = 'https://workspace.krishnapulluri5.replit.app/api';

export const API = {
  BASE_URL,
  // Auth
  LOGIN:    `${BASE_URL}/auth/login`,
  REGISTER: `${BASE_URL}/auth/register`,
  LOGOUT:   `${BASE_URL}/auth/logout`,
  GOOGLE:   `${BASE_URL}/auth/google`,
  // Agent
  ASSIGNED_STUDENTS: `${BASE_URL}/agent/students`,
  STUDENT_JOBS:      `${BASE_URL}/agent/queue`,
  MARK_APPLIED:      `${BASE_URL}/agent/mark-applied`,
  STUDENT_INFO:      `${BASE_URL}/agent/student-info`,
  DOWNLOAD_RESUME:   `${BASE_URL}/agent/resume`,
  // Student
  MY_JOBS:           `${BASE_URL}/student/jobs`,
  UPLOAD_RESUME:     `${BASE_URL}/student/resume`,
  MY_PROFILE:        `${BASE_URL}/student/profile`,
  // AI
  AI_ANSWER:         `${BASE_URL}/ai/generate-answer`,
  COVER_LETTER:      `${BASE_URL}/ai/generate-cover-letter`,
  TAILOR_RESUME:     `${BASE_URL}/ai/improve-resume`,
  // Admin
  ADMIN_STATS:       `${BASE_URL}/admin/stats`,
  ADMIN_USERS:       `${BASE_URL}/admin/users`
};
