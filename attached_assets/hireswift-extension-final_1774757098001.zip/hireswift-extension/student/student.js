import { API, CONFIG } from '../config.js';

let token = null, user = null, currentStudent = null, currentJob = null;

async function init() {
  const result = await chrome.storage.local.get([CONFIG.TOKEN_KEY, CONFIG.USER_KEY, CONFIG.CURRENT_STUDENT_KEY]);
  if (!result[CONFIG.TOKEN_KEY]) { window.location.href = '../auth/login.html'; return; }

  token = result[CONFIG.TOKEN_KEY];
  user = result[CONFIG.USER_KEY];
  currentStudent = result[CONFIG.CURRENT_STUDENT_KEY];

  if (!currentStudent) { window.location.href = '../popup/popup.html'; return; }

  document.getElementById('studentName').textContent = currentStudent.name || currentStudent.fullName || 'Student';
  document.getElementById('studentEmail').textContent = currentStudent.email;
  document.getElementById('logoutBtn').addEventListener('click', logout);

  setupButtons();
  await loadNextJob();
}

async function loadNextJob() {
  const loading = document.getElementById('loadingState');
  const content = document.getElementById('jobContent');
  const noJobs = document.getElementById('noJobsMsg');
  const infoSection = document.getElementById('studentInfoSection');

  loading.style.display = 'block';
  content.style.display = 'none';
  noJobs.style.display = 'none';
  if (infoSection) infoSection.style.display = 'none';

  try {
    const res = await fetch(`${API.STUDENT_JOBS}?email=${encodeURIComponent(currentStudent.email)}`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (res.status === 401) { logout(); return; }
    const data = await res.json();
    loading.style.display = 'none';

    if (!data.job) { noJobs.style.display = 'block'; return; }

    currentJob = data.job;
    document.getElementById('jobNumber').textContent = `Job #${currentJob.jobNumber || 1}`;
    const link = document.getElementById('jobLink');
    link.href = currentJob.jobLink;
    link.textContent = currentJob.jobLink;
    document.getElementById('jobDescription').textContent = currentJob.jobDescription || 'No description provided.';
    content.style.display = 'block';

    // Reset applied button
    const appliedBtn = document.getElementById('appliedBtn');
    appliedBtn.textContent = '✓ Mark Applied';
    appliedBtn.disabled = false;

  } catch (err) {
    loading.style.display = 'none';
    showError('Failed to load job. Please try again.');
  }
}

function setupButtons() {
  document.getElementById('startBtn').addEventListener('click', () => {
    if (!currentJob) return;
    chrome.runtime.sendMessage({ action: 'openTab', url: currentJob.jobLink });
  });

  document.getElementById('copyLinkBtn').addEventListener('click', async () => {
    await copyText(currentJob?.jobLink || '', document.getElementById('copyLinkBtn'));
  });

  document.getElementById('resumeBtn').addEventListener('click', downloadResume);
  document.getElementById('detailsBtn').addEventListener('click', loadStudentInfo);
  document.getElementById('appliedBtn').addEventListener('click', markApplied);
  document.getElementById('aiAnswerBtn').addEventListener('click', () => callAI('answer'));
  document.getElementById('coverLetterBtn').addEventListener('click', () => callAI('cover'));
  document.getElementById('tailorResumeBtn').addEventListener('click', () => callAI('tailor'));
  document.getElementById('copyAiBtn').addEventListener('click', () => {
    copyText(document.getElementById('aiAnswer').value, document.getElementById('copyAiBtn'));
  });
}

async function markApplied() {
  if (!currentJob || !confirm('Confirm you have applied to this job?')) return;
  const btn = document.getElementById('appliedBtn');
  btn.disabled = true;
  btn.textContent = 'Marking...';

  try {
    const res = await fetch(`${API.MARK_APPLIED}?job_id=${encodeURIComponent(currentJob.jobId)}&email=${encodeURIComponent(currentJob.email)}`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed');
    btn.textContent = '✓ Applied!';
    setTimeout(() => loadNextJob(), 1500);
  } catch (err) {
    showError(err.message);
    btn.disabled = false;
    btn.textContent = '✓ Mark Applied';
  }
}

async function downloadResume() {
  if (!currentJob?.resumePath) { showError('No resume for this job.'); return; }
  const btn = document.getElementById('resumeBtn');
  btn.disabled = true;
  btn.textContent = 'Fetching...';
  try {
    const res = await fetch(`${API.DOWNLOAD_RESUME}?email=${encodeURIComponent(currentStudent.email)}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed');
    chrome.runtime.sendMessage({ action: 'openTab', url: data.resumeUrl });
  } catch (err) {
    showError(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = '⬇ Resume';
  }
}

async function loadStudentInfo() {
  const btn = document.getElementById('detailsBtn');
  const section = document.getElementById('studentInfoSection');
  btn.disabled = true;
  btn.textContent = 'Loading...';
  try {
    const res = await fetch(`${API.STUDENT_INFO}?email=${encodeURIComponent(currentStudent.email)}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed');
    renderStudentInfo(data.studentInfo || data);
    section.style.display = 'block';
    section.scrollIntoView({ behavior: 'smooth' });
  } catch (err) {
    showError(err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = '👤 Student Info';
  }
}

function renderStudentInfo(info) {
  const container = document.getElementById('studentInfoContent');
  container.innerHTML = '';
  if (!info) { container.innerHTML = '<p style="padding:12px;color:#555">No info available.</p>'; return; }

  const groups = {
    '👤 Personal': ['firstName','lastName','fullName','email','phone','dateOfBirth','gender'],
    '📍 Address':  ['addressLine1','city','state','postalCode','country'],
    '💼 Work Auth': ['workAuthorization','visaStatus','requireSponsorship'],
    '⚙️ Preferences': ['preferredWork','targetCompensation','openToRelocation'],
    '🔐 Account':  ['password']
  };

  Object.entries(groups).forEach(([group, fields]) => {
    const groupDiv = document.createElement('div');
    groupDiv.className = 'info-group';
    groupDiv.innerHTML = `<div class="info-group-title">${group}</div>`;

    fields.forEach(key => {
      const val = info[key] || info.personalData?.[key];
      if (!val) return;
      const row = document.createElement('div');
      row.className = 'info-field';
      row.innerHTML = `
        <span class="info-label">${formatLabel(key)}</span>
        <div style="display:flex;align-items:center">
          <span class="info-value">${val}</span>
          <button class="btn-copy-sm" onclick="copyToClip('${String(val).replace(/'/g,"\\'")}', this)">Copy</button>
        </div>`;
      groupDiv.appendChild(row);
    });

    if (groupDiv.children.length > 1) container.appendChild(groupDiv);
  });
}

async function callAI(type) {
  const question = document.getElementById('aiQuestion').value.trim();
  const result = document.getElementById('aiResult');
  const answer = document.getElementById('aiAnswer');
  const btns = document.querySelectorAll('.btn-ai');

  btns.forEach(b => b.disabled = true);
  result.style.display = 'block';
  answer.value = 'Generating...';

  let endpoint = API.AI_ANSWER;
  if (type === 'cover') endpoint = API.COVER_LETTER;
  if (type === 'tailor') endpoint = API.TAILOR_RESUME;

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question,
        jobId: currentJob?.jobId,
        email: currentStudent?.email,
        jobDescription: currentJob?.jobDescription
      })
    });
    const data = await res.json();
    answer.value = data.answer || data.coverLetter || data.improvedResume || 'No response generated.';
  } catch (err) {
    answer.value = 'Failed to generate. Please try again.';
  } finally {
    btns.forEach(b => b.disabled = false);
  }
}

async function copyText(text, btn) {
  try {
    await navigator.clipboard.writeText(text);
    const orig = btn.textContent;
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = orig, 2000);
  } catch { btn.textContent = 'Failed'; }
}

window.copyToClip = async (text, btn) => copyText(text, btn);

function formatLabel(key) {
  return key.replace(/([A-Z])/g, ' $1').replace(/_/g, ' ')
    .trim().split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

function showError(msg) {
  const el = document.getElementById('errorMsg');
  el.textContent = msg;
  el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 5000);
}

async function logout() {
  await chrome.storage.local.clear();
  window.location.href = '../auth/login.html';
}

init();
